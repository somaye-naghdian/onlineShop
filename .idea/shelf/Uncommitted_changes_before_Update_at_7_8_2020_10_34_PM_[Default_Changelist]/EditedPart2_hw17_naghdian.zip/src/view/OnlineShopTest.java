package view;

public class OnlineShopTest {

    public static void main(String[] args) {
        StartUp startUp = new StartUp();
        startUp.start();

    }
}