package service;

public enum OperationsType {
REGISTER,LOGIN,PURCHASE,Add;
}
