package service;

import dao.UserDao;
import entity.Address;
import entity.User;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import sun.plugin.dom.exception.InvalidAccessException;

import java.util.Scanner;

public class CustomerService {
    static UserDao userDao = new UserDao();
    static ProductService productService = new ProductService();
    private static final Logger logger = LogManager.getLogger(CustomerService.class);

    public void loginCustomer() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter username : ");
        String username = scanner.next();
        System.out.println("enter password : ");
        String password = scanner.next();
        User customer = userDao.passwordValidation(username, password);
        if (userDao.passwordValidation(username, password) != null) {
            System.out.println("successful login");
          //  logger.info("login");
            productService.executeMenu(customer);
        } else {
            System.out.println("customer not found ");
            return;
        }
    }

    public User customerRegister() {
        Scanner scanner = new Scanner(System.in);
        UserDao userDao = new UserDao();

        System.out.println("enter  name");
        String name = scanner.nextLine();
        System.out.println("enter  family");
        String family = scanner.nextLine();
        System.out.println("enter  age");
        int age = scanner.nextInt();
        System.out.println("enter  phone number with pattern xxx-xxxxxxx");
        String phone = scanner.next();
        System.out.println("enter  email");
        String email = scanner.next();
        System.out.println("enter  address->province");
        String province = scanner.next();
        System.out.println("enter  address->city");
        String city = scanner.next();
        System.out.println("enter  address->street");
        String street = scanner.next();
        System.out.println("enter  address->postalCode");
        int zipCode = scanner.nextInt();
        Address address = new Address();
        address.setProvince(province);
        address.setCity(city);
        address.setStreet(street);
        address.setZipCode(zipCode);
        System.out.println("enter a username Including at least 8 character ");
        String username = scanner.next();
        if (userDao.searchDuplicateUserName(username)) {
        System.out.println("enter password Including at least 8 character and les than 10");
        String password = scanner.next();

        User customer = new User();
        customer.setName(name);
        customer.setFamily(family);
        customer.setAge(age);
        customer.setPhone(phone);
        customer.setEmail(email);
        customer.setUserName(username);
        customer.setPassword(password);
        customer.setAddress(address);
        address.setUser(customer);
        userDao.insertUser(customer);
     //   productService.addActivity(customer,OperationsType.REGISTER );
         //   logger.info("register");
        return customer;
        } else {
            throw new InvalidAccessException("username is previously selected ");
        }
    }
}